package altimetrik.trip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripRestBoot {
	public static void main(String[] args) {
		SpringApplication.run(TripRestBoot.class, args);
	}
}
